// const submitBtn = document.getElementById('subdetails');
// submitBtn.addEventListener('click',myFun);


// // const reset = document.getElementById('reset');
// // reset.addEventListener('click',resetFun);

// // const handover = document.getElementById('handover').value;
// console.log(handover);

// // const handoverOne = document.getElementById('handoverOne');
// var form1 = document.getElementById('form1');

// console.log(shifts.value);

// // var handover = document.getElementById('handover').value;

// function myFun(event){
//     event.preventDefault();

//     var shifts = document.getElementById('shifts').value;
//     var shift = document.getElementById('shift');
//     const handoverOne = document.getElementById('handoverOne');
//     var handover = document.getElementById('handover').value;

//     var handover = document.getElementById('handover').value;
//     //console.log()
//     //console.log('hii');
//     //form1.reset();
//     shift.textContent = shifts;
//     handoverOne.innerHTML = handover;
//     //handoverOne.innerHTML = handover;

// }

// function resetFun(){

//     //var shifts = document.getElementById('shifts').value;
//     //var shift = document.getElementById('shift');
//     //const handoverOne = document.getElementById('handoverOne');
//     //var handover = document.getElementById('handover').value;

//     var handover = document.getElementById('handover');
//     console.log(handover);

//     handover.value = ''; 
//     //handover.innerHTML = '';
//     //handover.textContent = '';
//     console.log(handover);
// }






let previousLength = 0;

const handleInput = (event) => {
  const bullet = "\u2022";
  const newLength = event.target.value.length;
  //console.log(newLength);
  const characterCode = event.target.value.substr(-1).charCodeAt(0);
  //console.log(characterCode);

  if (newLength > previousLength) {
    if (characterCode === 10) {
      event.target.value = `${event.target.value}${bullet} `;
    } else if (newLength === 1) {
      event.target.value = `${bullet} ${event.target.value}`;
    }
  }
  
  previousLength = newLength;
}







//console.log('hiii');

// document.getElementById('subdetails').onclick = function(){
//     fun()
// };

// function fun(){
//     console.log('hii');
// }
