// const submitBtn = document.getElementById('submit');
//         submitBtn.addEventListener('click',showRepo);

// function thisRepo(){
    
// }



// function showRepo(event){

//     event.preventDefault();

//     const country = document.getElementById('country').value;
//     const fromdate = document.getElementById('fromdate').value;
//     const todate = document.getElementById('todate').value;

//     const myForm = document.getElementById('myForm');



//     console.log(country);
//     console.log(fromdate);
//     console.log(todate);
    

//     if(fromdate > todate){
//         alert("Enter correct dates");

//     }

//     else if(country.trim() === 'Select' && fromdate === '' && todate === ''){
//         alert('Fill all the details');
//     }

//     else if(country.trim() === 'Kenya' && fromdate !== '' && todate !== ''){
//         // myForm.reset();
//         document.getElementById('myTable').style.display = 'table';
//         document.getElementById('UgaTable').style.display = 'none';
//         document.getElementById('NBCTable').style.display = 'none';
//         document.getElementById('BwaTable').style.display = 'none';
//         document.getElementById('GhaTable').style.display = 'none';
//         document.getElementById('ZamTable').style.display = 'none';
//         document.getElementById('MozTable').style.display = 'none';
//         document.getElementById('AbtTable').style.display = 'none';
//         document.getElementById('MauTable').style.display = 'none';
//         document.getElementById('SeyTable').style.display = 'none';
        
//         myForm.reset();
//         console.log('hii');
//     }

//     else if(country.trim() === 'Uganda' && fromdate !== '' && todate !== ''){
//         document.getElementById('myTable').style.display = 'none';
//         document.getElementById('UgaTable').style.display = 'table';
//         document.getElementById('NBCTable').style.display = 'none';
//         document.getElementById('BwaTable').style.display = 'none';
//         document.getElementById('GhaTable').style.display = 'none';
//         document.getElementById('ZamTable').style.display = 'none';
//         document.getElementById('MozTable').style.display = 'none';
//         document.getElementById('AbtTable').style.display = 'none';
//         document.getElementById('MauTable').style.display = 'none';
//         document.getElementById('SeyTable').style.display = 'none';

//         myForm.reset();
//     }

//     else if(country.trim() === 'nbc' && fromdate !== '' && todate !== ''){
//         document.getElementById('myTable').style.display = 'none';
//         document.getElementById('UgaTable').style.display = 'none';
//         document.getElementById('NBCTable').style.display = 'table';
//         document.getElementById('BwaTable').style.display = 'none';
//         document.getElementById('GhaTable').style.display = 'none';
//         document.getElementById('ZamTable').style.display = 'none';
//         document.getElementById('MozTable').style.display = 'none';
//         document.getElementById('AbtTable').style.display = 'none';
//         document.getElementById('MauTable').style.display = 'none';
//         document.getElementById('SeyTable').style.display = 'none';

//         myForm.reset();
//     }


//     else if(country.trim() === 'Botswana' && fromdate !== '' && todate !== ''){
//         document.getElementById('myTable').style.display = 'none';
//         document.getElementById('UgaTable').style.display = 'none';
//         document.getElementById('NBCTable').style.display = 'none';
//         document.getElementById('BwaTable').style.display = 'table';
//         document.getElementById('GhaTable').style.display = 'none';
//         document.getElementById('ZamTable').style.display = 'none';
//         document.getElementById('MozTable').style.display = 'none';
//         document.getElementById('AbtTable').style.display = 'none';
//         document.getElementById('MauTable').style.display = 'none';
//         document.getElementById('SeyTable').style.display = 'none';

//         myForm.reset();
//     }

//     else if(country.trim() === 'Ghana' && fromdate !== '' && todate !== ''){
//         document.getElementById('myTable').style.display = 'none';
//         document.getElementById('UgaTable').style.display = 'none';
//         document.getElementById('NBCTable').style.display = 'none';
//         document.getElementById('BwaTable').style.display = 'none';
//         document.getElementById('GhaTable').style.display = 'table';
//         document.getElementById('ZamTable').style.display = 'none';
//         document.getElementById('MozTable').style.display = 'none';
//         document.getElementById('AbtTable').style.display = 'none';
//         document.getElementById('MauTable').style.display = 'none';
//         document.getElementById('SeyTable').style.display = 'none';

//         myForm.reset();
//     }

//     else if(country.trim() === 'Zambia' && fromdate !== '' && todate !== ''){
//         document.getElementById('myTable').style.display = 'none';
//         document.getElementById('UgaTable').style.display = 'none';
//         document.getElementById('NBCTable').style.display = 'none';
//         document.getElementById('BwaTable').style.display = 'none';
//         document.getElementById('GhaTable').style.display = 'none';
//         document.getElementById('ZamTable').style.display = 'table';
//         document.getElementById('MozTable').style.display = 'none';
//         document.getElementById('AbtTable').style.display = 'none';
//         document.getElementById('MauTable').style.display = 'none';
//         document.getElementById('SeyTable').style.display = 'none';

//         myForm.reset();
//     }

//     else if(country.trim() === 'Moz' && fromdate !== '' && todate !== ''){
//         document.getElementById('myTable').style.display = 'none';
//         document.getElementById('UgaTable').style.display = 'none';
//         document.getElementById('NBCTable').style.display = 'none';
//         document.getElementById('BwaTable').style.display = 'none';
//         document.getElementById('GhaTable').style.display = 'none';
//         document.getElementById('ZamTable').style.display = 'none';
//         document.getElementById('MozTable').style.display = 'table';
//         document.getElementById('AbtTable').style.display = 'none';
//         document.getElementById('MauTable').style.display = 'none';
//         document.getElementById('SeyTable').style.display = 'none';

//         myForm.reset();
//     }



//     else if(country.trim() === 'abt' && fromdate !== '' && todate !== ''){
//         document.getElementById('myTable').style.display = 'none';
//         document.getElementById('UgaTable').style.display = 'none';
//         document.getElementById('NBCTable').style.display = 'none';
//         document.getElementById('BwaTable').style.display = 'none';
//         document.getElementById('GhaTable').style.display = 'none';
//         document.getElementById('ZamTable').style.display = 'none';
//         document.getElementById('MozTable').style.display = 'none';
//         document.getElementById('AbtTable').style.display = 'table';
//         document.getElementById('MauTable').style.display = 'none';
//         document.getElementById('SeyTable').style.display = 'none';


//         myForm.reset();
//     }



//     else if(country.trim() === 'mau' && fromdate !== '' && todate !== ''){
//         document.getElementById('myTable').style.display = 'none';
//         document.getElementById('UgaTable').style.display = 'none';
//         document.getElementById('NBCTable').style.display = 'none';
//         document.getElementById('BwaTable').style.display = 'none';
//         document.getElementById('GhaTable').style.display = 'none';
//         document.getElementById('ZamTable').style.display = 'none';
//         document.getElementById('MozTable').style.display = 'none';
//         document.getElementById('AbtTable').style.display = 'none';
//         document.getElementById('MauTable').style.display = 'table';
//         document.getElementById('SeyTable').style.display = 'none';

//         myForm.reset();
//     }

//     else if(country.trim() === 'sey' && fromdate !== '' && todate !== ''){
//         document.getElementById('myTable').style.display = 'none';
//         document.getElementById('UgaTable').style.display = 'none';
//         document.getElementById('NBCTable').style.display = 'none';
//         document.getElementById('BwaTable').style.display = 'none';
//         document.getElementById('GhaTable').style.display = 'none';
//         document.getElementById('ZamTable').style.display = 'none';
//         document.getElementById('MozTable').style.display = 'none';
//         document.getElementById('AbtTable').style.display = 'none';
//         document.getElementById('MauTable').style.display = 'none';
//         document.getElementById('SeyTable').style.display = 'table';

//         myForm.reset();
//     }




//     else{
//         //thisRepo();

//         console.log('jbjh');

//     }

// }




