var psw1 = document.getElementById('psw1');
var psw2 = document.getElementById('psw2');
var registerMsg = document.getElementById('registerMsg');

// console.log(psw1.value);
// console.log(psw2.value);

function register(){

    if(psw1.value === psw2.value ){
        registerMsg.innerHTML = "Registered successfull";
    }
    if(psw1.value == '' & psw2.value == ''){
        alert('enter some value');
        // registerMsg.innerHTML = "Password Mismatch!!";
    }

    if(psw1.value != psw2.value){
        alert('not done');
    }

}