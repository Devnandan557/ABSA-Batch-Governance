var openPopupBtn = document.querySelector('#open-popup-btn');
        var closePopupBtn = document.querySelector('.popup-close-btn');
        var cancel = document.querySelector('#cancel');
        
        openPopupBtn.addEventListener("click", function(event){
            event.preventDefault()
            document.body.classList.add("popup-active");
        });

        closePopupBtn.addEventListener("click", function(event){
            event.preventDefault()
            document.body.classList.remove("popup-active");
        })

        cancel.addEventListener("click", function(event){
            event.preventDefault()
            document.body.classList.remove("popup-active");
        })